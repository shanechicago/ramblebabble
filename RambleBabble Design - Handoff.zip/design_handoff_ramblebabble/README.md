# Handoff: RambleBabble — voice-first "talk messy, leave polished" app

## Overview
RambleBabble turns messy spoken thoughts (or pasted messy text) into polished — or
deliberately playful — written output. The user records a "ramble" (or pastes text),
picks **what** it should become and **what tone**, optionally supplies custom vocabulary,
then taps **Polish it** / **Babble it** to get back clean, ready-to-use text. There's also
a **My Rambles** history.

Tagline: **"Talk messy. Leave polished — or leave hilarious."**

Audience: people who would rather not type — folks who find typing intimidating or
physically hard, or who simply think better out loud. So the bar for **accessibility** is
high: large touch targets (≥44px, primary actions 56–64px), high contrast, large readable
type (17px body floor), plain-language labels, one-handed mobile use. Voice-first: the
record button is the hero of the main screen.

## About the Design Files
The files in this bundle are **design references created in HTML** — a working prototype
that demonstrates the intended look, motion, and behavior. They are **not** production code
to copy directly.

- `RambleBabble.dc.html` is the design. It uses a small in-house preview runtime
  ("Design Components") — it is **not** React/Next source. Treat its two halves as a spec:
  - The **template** (markup inside `<x-dc>`) is plain HTML with `{{ value }}` holes,
    `<sc-for>` (a loop) and `<sc-if>` (a conditional). It maps almost 1:1 to JSX.
  - The **`class Component extends DCLogic`** block is effectively a React class component
    without `render()`: it has `state`, `setState`, lifecycle methods, and a `renderVals()`
    that returns derived values + event handlers consumed by the template. All real logic
    (the text-cleaning + format generators, the recording timer, the polish flow) lives here
    and ports directly to a React component / hooks.
- `support.js` is **only** the preview runtime. You do **not** need it in the real app.

**Your task:** recreate this design in the target codebase's environment. The brief calls
for a **Next.js + Tailwind** app, so: build it with the App Router, React function
components, and Tailwind utility classes, lifting the exact tokens and behavior documented
below. If a component library / design system already exists in the target repo, prefer its
primitives and apply these tokens to them.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, motion, and interactions are all
specified. Recreate the UI pixel-perfectly. Exact hex values, sizes, and copy are below and
in the source file.

---

## Design Tokens

The prototype themes via CSS custom properties on a wrapper that carries `data-theme`
(`dark` default / `light`) and `data-accent` (`lime` default / `cyan` / `coral`, which only
remaps the "signal" color). For Tailwind, expose these as CSS variables in `globals.css` and
reference them in `tailwind.config` (e.g. `colors: { primary: 'var(--primary)' }`), or hard-map
the dark/light values into a Tailwind theme with a `dark:` variant.

### Color — Dark (default)
| Token | Hex / value | Use |
|---|---|---|
| `--bg` | `#0a0b12` | App background |
| `--bg-soft` | `#0e1019` | — |
| `--surface` | `#14161f` | Cards, inputs |
| `--surface2` | `#1b1e29` | Recessed fields, secondary buttons |
| `--surface3` | `#262a38` | Chips, track fills, disabled button |
| `--border` | `rgba(255,255,255,.09)` | Default borders |
| `--border-strong` | `rgba(255,255,255,.17)` | Hover borders |
| `--text` | `#f3f4f8` | Primary text |
| `--text-dim` | `#a7abbd` | Secondary text / labels |
| `--text-faint` | `#6c7186` | Tertiary / hints |
| `--primary` | `#7b5cff` | Brand violet — CTAs, links, selection |
| `--primary-soft` | `rgba(123,92,255,.16)` | Selected-chip fill |
| `--primary-ink` | `#fff` | Text on primary |
| `--signal` | `#c8ff43` | Electric lime — recording/live state, "Polish it" |
| `--signal-ink` | `#0a0b12` | Text on signal |
| `--danger` | `#ff5d73` | Errors, destructive |
| `--danger-soft` | `rgba(255,93,115,.14)` | Error surface |
| `--glow1` | `rgba(123,92,255,.40)` | Violet ambient glow / shadow |
| `--glow2` | `rgba(200,255,67,.20)` | Lime ambient glow |
| `--fun1` | `#ff4d9d` | "Just for Fun" pink |
| `--fun2` | `#ffa53d` | "Just for Fun" amber |
| `--fun-soft` | `rgba(255,77,157,.13)` | Fun panel / selected fill |
| `--fun-glow` | `rgba(255,77,157,.32)` | Fun glow / shadow |
| `--shadow` | `0 18px 50px -12px rgba(0,0,0,.6)` | Result card shadow |

### Color — Light (`data-theme="light"`)
| Token | Hex / value |
|---|---|
| `--bg` | `#f4f4f1` |
| `--bg-soft` | `#eeeeea` |
| `--surface` | `#ffffff` |
| `--surface2` | `#f3f3f7` |
| `--surface3` | `#e9e9f0` |
| `--border` | `rgba(20,18,40,.10)` |
| `--border-strong` | `rgba(20,18,40,.20)` |
| `--text` | `#161726` |
| `--text-dim` | `#565a6e` |
| `--text-faint` | `#888da0` |
| `--primary` | `#6a45ff` |
| `--primary-soft` | `rgba(106,69,255,.10)` |
| `--signal` | `#a6e600` |
| `--signal-ink` | `#16240a` |
| `--danger` | `#e23a52` |
| `--danger-soft` | `rgba(226,58,82,.10)` |
| `--glow1` | `rgba(106,69,255,.18)` |
| `--glow2` | `rgba(166,230,0,.18)` |
| `--fun1` | `#ff2e8b` |
| `--fun2` | `#ff8c1a` |
| `--fun-soft` | `rgba(255,46,139,.09)` |
| `--fun-glow` | `rgba(255,46,139,.22)` |
| `--shadow` | `0 18px 50px -16px rgba(40,30,90,.20)` |

### Accent override (`data-accent`) — remaps `--signal` only
- `cyan`: `--signal:#34e7e0; --signal-ink:#06231f; --glow2:rgba(52,231,224,.22)`
- `coral`: `--signal:#ff7a4d; --signal-ink:#2a0e02; --glow2:rgba(255,122,77,.22)`

### Typography
Three families:
- **Clash Display** (Fontshare, weights 600/700) — wordmark, headings, the "Polish it"/"Babble it"
  button label, the "Just for Fun" heading. Letter-spacing −0.02em on big headings.
- **General Sans** (Fontshare, weights 400/500/600/700) — all UI and body. Base size **17px**,
  line-height 1.5.
- **JetBrains Mono** (Google Fonts, 500/700) — the recording timer readout only.

Font links used in the prototype:
```
https://api.fontshare.com/v2/css?f[]=clash-display@600,700&f[]=general-sans@400,500,600,700&display=swap
https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@500;700&display=swap
```
(In Next.js, prefer `next/font` — `next/font/local` for the Fontshare files, or self-host.)

Type scale actually used:
| Role | Size / weight / family |
|---|---|
| Hero headline (auth) | 34px / 600 / Clash Display / line-height 1.08 |
| Screen title ("My Rambles") | 28px / 600 / Clash Display |
| Wordmark (auth) | 32px / 700 / Clash Display; (header) 22px |
| Section labels ("YOUR WORDS", "TURN IT INTO…", "TONE") | 15px / 600 / uppercase / letter-spacing .06em / `--text-dim` |
| "Just for Fun" heading | 20px / 700 / Clash Display, gradient text |
| Body / inputs / option labels | 17px (inputs), 15.5px (option cards) / 600 |
| Timer | 30px / 700 / JetBrains Mono / `--signal-ink` |
| Primary button label | 19px / 700 / Clash Display |

### Spacing, radius, sizing
- Section vertical rhythm: 22–26px between blocks.
- Radii: inputs 14–15px, option cards 15px, large cards 18–22px, pills/chips 999px,
  icon buttons 12–14px, record circle 50%.
- Touch targets: option cards `min-height:58px`; tone pills 46px; primary buttons 56–64px;
  icon buttons 44–48px.
- App column: `max-width:480px`, centered; full-bleed on mobile. Whole app is a single
  centered column on a backdrop with two blurred radial "glow" blobs (`--glow1` top-left,
  `--glow2` bottom-right), each slowly floating.

### Motion (keyframes)
All gated by a `reduceMotion` flag (respect `prefers-reduced-motion`):
- `breathe` — idle record button, 3.4s ease-in-out (scale 1 → 1.045).
- `glowpulse` — glow behind idle record button, 3.4s.
- `ring` — recording: expanding concentric rings, 2.4s ease-out, 3 rings staggered 0.8s,
  scale .5→2.1, opacity .55→0, `2px solid var(--signal)`.
- `wave` — recording waveform: 40 bars, scaleY .28→1, per-bar duration 0.55–1.03s, staggered
  delays; bar fill `linear-gradient(180deg,var(--signal),var(--primary))`, width 4px,
  height varied 10–44px (deterministic via sine).
- `blink` — small "live" brand dot, 2.4s.
- `floaty` — ambient glow blobs (9s / 11s) and empty-state mic (4s).
- `twinkle` — "Just for Fun" ✦ sparkle, 2.6s (scale + 90° rotate + opacity).
- `rise` — entrance for screens/cards: from `opacity:0;translateY(8–10px)`, ~.35–.5s ease.
- `loadbar` — indeterminate progress bar sweep during loading, 1.1s.
- `spin` — loading spinner, .8s linear.
- Button press: `active` → `scale(.96–.99)`. Fun cards hover:
  `translateY(-3px) rotate(-0.6deg)` + border → `--fun1`.

---

## Screens / Views

The prototype is one component with a `screen` state machine: `auth | main | history`.
A persistent **app header** (sticky top) shows on `main` and `history`: brand wordmark (left),
theme toggle ☀/☾ and a **My Rambles / Record** toggle button (right).

### 1. Sign in / Sign up (`auth`)
- **Purpose:** frictionless entry. Username + password only.
- **Layout:** centered single column, padded 32/24px; theme toggle pinned top-right.
- **Components:**
  - Brand wordmark: "Ramble" in `--text` + "Babble" in `linear-gradient(120deg,var(--primary),var(--signal))` clipped to text; preceded by a pulsing `--signal` dot.
  - Hero headline: "Talk messy. / Leave polished — / **or hilarious.**" — last line in
    `linear-gradient(120deg,var(--fun1),var(--fun2))` clipped to text.
  - Subhead in `--text-dim`, 18px.
  - Segmented control: **Sign in** / **Create account** (6px padding track, `--surface2`,
    active segment `--surface`). Drives `authMode`; changes the CTA label only.
  - Inputs: Username, Password (58px tall, `--surface2`, focus → border `--primary` + bg `--surface`).
  - Inline validation message in `--danger` when username empty on submit.
  - Primary CTA: "Sign in & start talking" / "Create account" — 62px, `--primary`, white,
    shadow `0 12px 30px -10px var(--glow1)`.
  - Footer microcopy.
- **Behavior:** submit requires a non-empty username (only validation); on success →
  `screen='main'`. Password is not checked (prototype).

### 2. Main — Record & Polish (`main`)  *(the heart of the app)*
- **Purpose:** capture → choose output type + tone → polish → read/copy result.
- **Layout:** scrolling column, 22/18px padding, generous bottom padding. Sections top→bottom:
  Record hero → Transcript → Turn it into… → Just for Fun → Tone → Custom vocabulary →
  Polish button → Results.

  **a. Record hero** has three states:
  - *Idle:* 188px circle, `linear-gradient(150deg,var(--primary),color-mix(in srgb,var(--primary) 55%,#000))`,
    inner highlight + glow, **breathe** animation; white mic glyph; label "Record Ramble" (23px Clash Display) and
    hint "Tap and just start talking · up to 3 min".
  - *Recording:* 170px `--signal` circle showing the **mm:ss timer** (JetBrains Mono), 3 expanding
    `ring`s behind it, a 40-bar animated **waveform** below; at **150s** a pill warning
    "⏳ About 30 seconds left" (`--danger-soft`/`--danger`); **Cancel** (ghost) + **Stop** (primary,
    with white square) buttons. Hard limit **180s** → auto-stop.
  - *Recorded:* a confirmation row ("Got it — m:ss captured / Edit below, or re-record") with a
    re-record icon button.

  **b. Transcript:** label "YOUR WORDS" + a "Clear" link (shown when non-empty). A 130px-min
  editable `<textarea>` (`--surface`, focus border `--primary`), placeholder
  "Your transcript appears here — or paste messy text to polish." This is the single field for
  both recorded transcript and pasted text.

  **c. "Turn it into…" (practical, 8):** 2-col grid of selectable cards, each = small square
  color dot (alternating `--primary`/`--signal`) + label. Options, in order:
  **Cleaned note, Email, Text message, AI prompt, Bug report, Meeting notes, Product idea,
  Professional summary.** Selected card gets an inset 2px `--primary` ring + `--primary-soft` fill.

  **d. "Just for Fun" (8):** a visibly more playful panel — `--fun-soft` background, pink-tinted
  border (`color-mix(in srgb,var(--fun1) 32%,transparent)`), a blurred fun-glow blob top-right, a
  twinkling ✦ + gradient "Just for Fun" heading + subcopy "Let your Babble off the leash." Cards
  are 2-col, each with a **round gradient dot** (`linear-gradient(135deg,var(--fun1),var(--fun2))`,
  fun-glow shadow); hover lifts & tilts; selected = inset 2px `--fun1` ring + `--fun-soft` fill.
  Options: **Make Me Laugh, Drama Mode, Movie Trailer, Tall Tale, Meme It, Hype Machine,
  Make It Rhyme, Ye Olde English.** Both groups share **one** selection (`outputType`); picking a
  fun option puts the whole flow into "fun mode" (see below).

  **e. Tone (5):** wrapping row of pills — **Professional, Friendly, Direct, Polished,
  Keep my voice.** Selected pill = filled `--primary` with white text + glow.

  **f. Custom vocabulary:** collapsible. A row "＋ Custom vocabulary (names, brands, jargon)"
  toggles a single input ("e.g. Priya, Acme Corp, RambleBabble, OAuth") + hint
  "We'll keep these spelled exactly right in your polished text." (Prototype stores it; it is
  not yet applied to output — wire into the real model prompt.)

  **g. Action button:** full-width, 64px, Clash Display 19px, with a sparkle icon.
  - Practical mode: label **"Polish it"**, background `--signal`, ink `--signal-ink`,
    shadow uses `--glow2`.
  - Fun mode: label **"Babble it"**, background `linear-gradient(120deg,var(--fun1),var(--fun2))`,
    ink white, shadow uses `--fun-glow`.
  - Disabled (empty transcript): background `--surface3`, ink `--text-faint`, opacity .6.

  **h. Results / Loading / Error** (replaces nothing; appended below the button):
  - *Loading:* card with spinner + two-stage copy — "Listening closely… / Turning sound into
    text" then "Polishing your words…" (or **"Babbling…" / "Making your <type>"** in fun mode) +
    an indeterminate `loadbar`.
  - *Error:* `--danger`-bordered card, "😕 We couldn't quite catch that / There wasn't enough to
    work with…" + **Try again**. (Triggered when transcript < 10 chars after trim.)
  - *Done:* a header "POLISHED · <Type>" (or **"BABBLED · <Type>"**, with a `--fun1` dot and
    `--fun1` card border in fun mode); the polished output in a bordered card
    (`white-space:pre-wrap`, 17px, line-height 1.62); an optional **Key points** card (top 3
    points; omitted for "Text message" and all fun types); a collapsible **View raw transcript**;
    and an action row: **Copy** (primary), **Try again** (ghost), **Clear** (icon, destructive hover).
  - On a successful result the ramble is **prepended to My Rambles**.

### 3. My Rambles (`history`)
- **Purpose:** revisit, reopen, copy, or delete past rambles; welcoming empty state.
- **Layout:** "My Rambles" title (28px) + "Clear all" link; vertical list of cards.
- **Card:** a type chip (`--primary-soft`/`--primary` with the type's color dot) + a tone chip
  (`--surface3`) + relative date (right); a one-line snippet button (≤96 chars, hover →
  `--primary`); action row **Reopen / Copy / Delete(icon)**.
- **Reopen:** loads that ramble's transcript + type + tone + polished result back into the main
  screen (`recState='recorded'`, `polishState='done'`).
- **Empty state:** floating gradient mic in a glow, "No rambles yet", supportive copy, and a
  primary CTA "Record your first ramble" → back to main.
- Seeded with 3 example rambles in the prototype; replace with real persistence.

---

## Interactions & Behavior
- **Navigation:** `screen` state machine. Header right button toggles main↔history. Auth submit → main.
- **Theme toggle:** flips `theme` (`dark`/`light`) → sets `data-theme` on the root; ☀ in dark, ☾ in light.
- **Recording timer:** `setInterval` 1s incrementing `elapsed`; warning at `elapsed>=150`; auto-stop
  + finalize at `180`. On Stop, if the transcript is empty it's filled with a sample messy
  transcript (in a real app, the ASR result); if the user already pasted text it's preserved.
  Cancel resets to idle without touching the transcript.
- **Polish flow (simulated):** `runPolish` →
  - if `transcript.trim().length < 10` → after ~1.1s show **error**;
  - else `polishState`: `transcribing` (~0.95s) → `polishing` (~1.2s) → `done` (~2.15s total),
    producing `{ polished, keyPoints, raw }` and saving to history.
  - Replace these timeouts with real transcription + LLM calls. The custom-vocabulary and tone
    values should feed the model prompt.
- **Copy:** `navigator.clipboard.writeText` + a transient toast "Copied to clipboard" (1.8s).
- **Validation:** auth requires non-empty username; polish requires non-empty transcript
  (button disabled otherwise); short transcript → friendly error.
- **Responsive:** mobile-first single 480px column; on desktop it stays centered on the glow
  backdrop. All grids are 2-col; everything is touch-first.

### The output generators (port these — they make output feel responsive to input)
The prototype does light real text processing so output reflects the user's actual words. In the
real app these become the model prompt/spec, but the shape is useful:
- `cleanText(raw)` — lowercases, strips filler words (`um, uh, like, you know, basically, kind of,
  okay so, oh and, …`), collapses whitespace, fixes punctuation spacing.
- `sentences(clean)` — splits run-on speech on connectors (`and`, `and then`, `and also`, commas,
  semicolons, periods) into discrete thoughts.
- **Practical formats** wrap those sentences: *Cleaned note* = clean paragraph; *Email* = tone-based
  greeting + body + sign-off; *Text message* = first 1–2 sentences; *AI prompt* = "You are…/Task/Context"
  scaffold; *Bug report* = Title/Steps/Expected/Actual/Priority; *Meeting notes* = bullets + action
  items; *Product idea* = Problem/Idea/Why now/Next step; *Professional summary* = "Summary: …".
- **Tone** changes greeting/sign-off wording (Professional/Friendly/Direct/Polished/Keep my voice).
- **Fun formats** transform the same sentences playfully: *Make Me Laugh* (stand-up riff),
  *Drama Mode* ("In a world…"), *Movie Trailer* (gravelly VO + "RAMBLEBABBLE PICTURES… Rated R. For
  Rambling."), *Tall Tale* (folklore), *Meme It* (Nobody:/Me:/TOP-BOTTOM TEXT), *Hype Machine*
  (ALL CAPS hype), *Make It Rhyme* (a 4-line verse with fixed see/be + mix/fix rhymes),
  *Ye Olde English* (thee/thy/aye/nay/"Hark!… good morrow"). Full implementations are in the
  `format()` method of the source file — copy them verbatim as a starting point.

## State Management
Single component state (lift to React state/hooks, or a store):
`screen`, `theme`, `authMode`, `username`, `password`, `authError`, `recState`
(`idle|recording|recorded`), `elapsed`, `transcript`, `outputType`, `tone`, `vocabOpen`,
`vocab`, `polishState` (`idle|transcribing|polishing|done|error`), `result`
(`{polished, keyPoints[], raw}`), `rambles[]`, `toast`. Plus non-state refs: the timer interval
and the polish timeouts (clear on unmount). Tweakable props in the prototype: `accent`
(`lime|cyan|coral`), `reduceMotion` (bool), `startScreen` (`auth|main|history`).

For the real app: persist `rambles` (DB or localStorage), wire `recState` to the
MediaRecorder/Web Speech API, and replace the polish timeouts with transcription + LLM requests.

## Assets
- **No image assets.** All icons are simple inline SVGs (mic, check, copy, trash, sparkle,
  chevrons) drawn from basic primitives — recreate with your icon library (Lucide etc.) or keep
  the inline SVGs from the source.
- Fonts: Clash Display + General Sans (Fontshare), JetBrains Mono (Google) — see Typography.
- The ✦ sparkle and ☀/☾/⏳/😕 are Unicode glyphs, not image assets.

## Files
- `RambleBabble.dc.html` — the complete design: template (markup) + `class Component` (all logic,
  including the text generators) + design-token CSS at the top of `<helmet>`. **This is the
  source of truth** for exact markup, styles, copy, and behavior.
- `support.js` — preview runtime only; **not needed** in the real app. Included so the HTML can be
  opened standalone in a browser to click through the design.

To preview: open `RambleBabble.dc.html` in a browser (it loads `support.js` from the same folder).
