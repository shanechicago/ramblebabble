# RambleBabble — Screen Captures

These are rendered captures of the HTML prototype (`RambleBabble.dc.html`), for visual
reference alongside the spec in `README.md`. They live in the `screenshots/` folder.

> **Capture caveats (the real app will look better):**
> - The captures use a DOM rasterizer that **cannot load the cross-origin webfonts**, so headings
>   render in a fallback serif/sans rather than **Clash Display / General Sans**. Use the fonts
>   named in `README.md`.
> - Gradient **clip-text** (the "Babble" wordmark, the "or hilarious." line, the "Just for Fun"
>   heading) is shown as a flat fallback color in the sign-in frames; in the app these are the
>   intended `--primary→--signal` / `--fun1→--fun2` gradients.
> - Each frame is the ~480px app column centered on its glow backdrop; on a phone the column is
>   full-bleed.

| File | Screen / state |
|---|---|
| `01-signin-hero.png` | **Sign in** — wordmark, "Talk messy. Leave polished — or hilarious." headline, intro copy (dark) |
| `02-signin-form.png` | **Sign in** — Sign in / Create account segmented control, username + password, primary CTA |
| `03-record-dark.png` | **Main / Record** — idle hero record button, transcript field (dark) |
| `04-recording.png` | **Main / Recording** — live lime timer (0:03), expanding rings, animated waveform, Cancel / Stop |
| `05-choosers.png` | **Main** — "Turn it into…" 8-card grid + the start of the "Just for Fun" panel |
| `06-just-for-fun.png` | **Main** — the full "Just for Fun" panel with **Movie Trailer** selected (pink ring) |
| `07-result-babbled.png` | **Main / Result** — "Babble it" gradient button + the **BABBLED · MOVIE TRAILER** output card |
| `08-history-dark.png` | **My Rambles** — saved-ramble cards with type/tone chips and Reopen / Copy / Delete (dark) |
| `09-record-light.png` | **Main / Record** — the same record screen in the **light** theme |
| `10-history-light.png` | **My Rambles** — history list in the **light** theme |

Not separately captured (described fully in `README.md`): the **recorded** confirmation state, the
**30-seconds-left** warning, the **loading** (transcribing/polishing) state, the friendly **error**
state, the **empty** My Rambles state, and the **cyan / coral** accent variants.
